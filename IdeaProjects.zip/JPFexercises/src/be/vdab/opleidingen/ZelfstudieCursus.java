package be.vdab.opleidingen;

public class ZelfstudieCursus extends Cursus{
}
