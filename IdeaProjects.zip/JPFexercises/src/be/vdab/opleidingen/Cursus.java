package be.vdab.opleidingen;

public class Cursus{
}
