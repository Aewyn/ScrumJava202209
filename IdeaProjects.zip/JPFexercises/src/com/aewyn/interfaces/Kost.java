package com.aewyn.interfaces;

public interface Kost {
    double bedragKost();
    boolean personeelsKost();
}
