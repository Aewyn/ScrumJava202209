package com.aewyn.voorwerpen;

public class Isbn13Exception extends RuntimeException {
    public Isbn13Exception(){}
    public Isbn13Exception(String msg){
        super(msg);
    }
}
