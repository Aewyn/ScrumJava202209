package com.aewyn.practice;

public class MainSpaarrekening {

    public static void main(String[] args) {
        //var getal1 = new Getal(10);

        //System.out.println(getal1.getX());

        //var spaar1 = new Spaarrekening("BE12 3456 7890 1234", 1.5, -20);

        //spaar1.storten(-5);

        //System.out.println(Spaarrekening.getIntrest());
    }
}