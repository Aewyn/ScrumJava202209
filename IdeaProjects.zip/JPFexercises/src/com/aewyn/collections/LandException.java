package com.aewyn.collections;

public class LandException extends RuntimeException{
    public LandException(){

    }
    public LandException(String msg){
        super(msg);
    }
}
