package com.aewyn.voertuigen;

public interface Vervuiler {
    double berekenVervuiling();
}
