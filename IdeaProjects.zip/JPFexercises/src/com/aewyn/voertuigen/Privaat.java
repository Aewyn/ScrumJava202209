package com.aewyn.voertuigen;

public interface Privaat {
    void geefPrivateData();
}
