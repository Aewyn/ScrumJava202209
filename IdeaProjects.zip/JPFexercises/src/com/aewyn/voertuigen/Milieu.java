package com.aewyn.voertuigen;

public interface Milieu {
    void geefMilieuDetail();
}
