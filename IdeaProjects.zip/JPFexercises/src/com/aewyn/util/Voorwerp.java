package com.aewyn.util;

public interface Voorwerp {
    void gegevensTonen();
    float winstBerekenen();
}
