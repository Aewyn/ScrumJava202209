package com.aewyn.persoon;

public enum Geslacht {
    MAN, VROUW;
}
